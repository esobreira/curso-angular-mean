"use strict";
var logo_component_1 = require("../logo/logo.component"); //observe a localização
var cadastro_component_1 = require("../cadastro/cadastro.component");
var lista_component_1 = require("../lista/lista.component");
var notFound_component_1 = require("../erro/notFound.component");
var masterdetail_component_1 = require("../masterdetail/masterdetail.component");
var masterdetaildb_component_1 = require("../masterdetail/masterdetaildb.component");
exports.appRoutes = [
    { path: "", component: logo_component_1.LogoComponent },
    { path: "cadastro", component: cadastro_component_1.CadastroComponent },
    { path: "lista", component: lista_component_1.ListaComponent },
    { path: "masterdetail", component: masterdetail_component_1.MasterDetailComponent },
    { path: "masterdetaildb", component: masterdetaildb_component_1.MasterDetailDbComponent },
    { path: "**", component: notFound_component_1.NotFoundComponent }
];
//# sourceMappingURL=app.routes.js.map