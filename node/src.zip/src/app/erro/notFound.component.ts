import { Component } from '@angular/core';

@Component({
    template: `
     <div class="container margem">
        <h1>ERRO 404 - PÁGINA NÃO LOCALIZADA</h1>
     </div>
     `
})
export class NotFoundComponent{}