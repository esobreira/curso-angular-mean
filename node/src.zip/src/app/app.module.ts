import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { HttpModule } from '@angular/http';

import { appRoutes } from './rotas/app.routes'; //deve vir primeiro
import { AppComponent }  from './app.component';
import { MenuComponent } from './menu/menu.component';
import { VerificaCh } from './filters/verificach.filter';
import { SubLista } from './filters/sublista.filter';

//usado nas rotas
import { LogoComponent } from './logo/logo.component';
import { CadastroComponent } from './cadastro/cadastro.component';
import { ListaComponent } from './lista/lista.component';
import { NotFoundComponent } from './erro/notFound.component';
import { MasterDetailComponent } from './masterdetail/masterdetail.component';
import { MasterDetailDbComponent } from './masterdetail/masterdetaildb.component';

//services
import { CursosService } from './services/cursos.service';

@NgModule({
  imports:      [ BrowserModule, RouterModule.forRoot(appRoutes), FormsModule, 
                  HttpModule ], //lista os modulos que a aplicação necessitara
  declarations: [ AppComponent, 
                  MenuComponent, 
                  LogoComponent,
                  CadastroComponent, 
                  ListaComponent, 
                  NotFoundComponent,
                  MasterDetailComponent, MasterDetailDbComponent,
                  VerificaCh, SubLista ],  //lista os componentes que nossa aplicação utilizará

  providers: [ CursosService ],                  
  bootstrap:    [ AppComponent ]   //este é o componente inicial, aquele que será incluído no index.html
})
export class AppModule { }
