class Pessoa {
    static total: number = 0;

    constructor (protected nome: string, protected idade: number){
        Pessoa.total += 1;
    }
}

class Aluno extends Pessoa {
    private curso: string;

    public setCurso(curso: string) {
        this.curso = curso;
    }
    constructor(curso: string, nome: string, idade: number){
        super(nome, idade);
        this.curso = curso;
    }
}

interface IPonto {
    x: number;
    y: number;

    ehQuadrado(): boolean;
}

class Ponto implements IPonto{

    public x: number;
    public y: number;

    constructor (x: number, y: number ){
        this.x = x;
        this.y = y;
    }

    public ehQuadrado(): boolean {
        return this.x == this.y;
    }    
}

class Teste {
    public testar(): void {
        let aluno = new Aluno("javascript", "Andre", 25);

        //alterando seus valores
        aluno.setCurso('Turismo');

        let ponto = new Ponto(10,10);
        alert(ponto.ehQuadrado() ? "É um quadrado" : "Não é um quadrado");
    }
}