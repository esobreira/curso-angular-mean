var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Pessoa = (function () {
    function Pessoa(nome, idade) {
        this.nome = nome;
        this.idade = idade;
        Pessoa.total += 1;
    }
    return Pessoa;
}());
Pessoa.total = 0;
var Aluno = (function (_super) {
    __extends(Aluno, _super);
    function Aluno(curso, nome, idade) {
        var _this = _super.call(this, nome, idade) || this;
        _this.curso = curso;
        return _this;
    }
    Aluno.prototype.setCurso = function (curso) {
        this.curso = curso;
    };
    return Aluno;
}(Pessoa));
var Ponto = (function () {
    function Ponto(x, y) {
        this.x = x;
        this.y = y;
    }
    Ponto.prototype.ehQuadrado = function () {
        return this.x == this.y;
    };
    return Ponto;
}());
var Teste = (function () {
    function Teste() {
    }
    Teste.prototype.testar = function () {
        var aluno = new Aluno("javascript", "Andre", 25);
        //alterando seus valores
        aluno.setCurso('Turismo');
        var ponto = new Ponto(10, 10);
        alert(ponto.ehQuadrado() ? "É um quadrado" : "Não é um quadrado");
    };
    return Teste;
}());
//# sourceMappingURL=exemplos.js.map