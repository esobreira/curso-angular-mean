export interface ICurso {
    codigo: number;
    descricao: string;
    ch: number;
}