import { Component } from '@angular/core';
import { ICurso } from '../classes/interface.curso';
import { CursosService } from '../services/cursos.service';


@Component({
    moduleId: module.id,
    templateUrl: 'views/masterdetail.component.html'

})
export class MasterDetailComponent {

    //para um curso selecionado
    public cursoSelecionado: ICurso;
    private novoCurso: ICurso;

    public selecionar(item: ICurso): void {
        this.cursoSelecionado = item;
    }

    //para a lista de cursos
    public listaCursos: ICurso[];

    
    constructor(private cursosService: CursosService) {
        //this.listaCursos = cursosService.getDisciplinas();    
        this.listar();
    }




    public listar(): void {
        this.cursosService.getCursos()
            .subscribe(res => this.listaCursos = res, error => alert(error), () => console.log('finalizado'));

    }
    //para a inclusão de um novo curso
    public novo() {
        this.novoCurso = { codigo: 0, descricao: '', ch: 0 }
        this.cursoSelecionado = this.novoCurso;
    }

    public incluir(curso: ICurso) {
        //this.listaCursos.push(curso);
        this.cursosService.setCurso(curso)
            .subscribe(res => JSON.stringify(res), error => alert(error), () => this.listar());

        alert('Curso incluído com sucesso');
    }
}
