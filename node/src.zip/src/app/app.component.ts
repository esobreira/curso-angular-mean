import { Component } from '@angular/core';
import { MenuComponent } from './menu/menu.component';

@Component({  
  selector: 'my-app',
  template: '<menu></menu>'
  //templateUrl: 'views/app.component.html'
})
export class AppComponent  {}
