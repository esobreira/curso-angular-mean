import { Component } from '@angular/core';

@Component({
    template: `
     <div class="container margem">
        <h1>PÁGINA INICIAL</h1>
     </div>
     `
})
export class LogoComponent{}