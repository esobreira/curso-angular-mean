import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'menu',
    templateUrl: 'views/menu.component.html'
})
export class MenuComponent {
    titulo_escola: string = "Impacta Treinamentos";
    titulo_cad: string = "Cadastro de Cursos";
    titulo_lista: string = "Listagem de Cursos";
    titulo_masterdetail = "Master/Detail";
    titulo_masterdetaildb = "Master/Detail - MongoDB";
}