import { Component } from '@angular/core';
import { ICurso } from '../classes/interface.curso';
import { CursosService } from '../services/cursos.service';

@Component({
    moduleId: module.id,
    templateUrl: 'views/lista.component.html'
    
})
export class ListaComponent{

    //definindo um array de cursos (2)
    /*
    public listaCursos: ICurso[] = [
    {codigo: 11, descricao:'Asp.Net', ch:40 },
    {codigo: 12, descricao:'Java Programmer', ch:40 },
    {codigo: 13, descricao:'C# Fundamentos', ch:60 },
    {codigo: 14, descricao:'Introdução à Logica de Programação', ch:24 }]; 
    */

    public listaCursos: ICurso[];
    constructor(cursosService: CursosService){
        this.listaCursos = cursosService.getDisciplinas();
        //cursosService.getCursos()
        //    .subscribe(res => this.listaCursos = res, error => alert(error), () => console.log('finalizado'));
    }
}
